# -*- coding: utf-8 -*-
"""
Created on Tues Nov  7 20:01:45 2017

@author: Dan Wendling

  ===========================================================
  |  PYTHON FOR BROWSING MESH 'PERSONS' TERMS IN PUBMED:    |
  |  Retrieve counts for selected branch of the MeSH tree.  |
  ===========================================================

This example counts PubMed studies that describe how various audiences 
seek and consume biomedical information. It aids in updating a wiki
page that has hyperlinks to pubmed.gov for each audience category.

Task: Let's say you are creating a new web resource for a particular 
audience, such as "caregivers." What do we know about the information
needs, information seeking, and information use behaviors of this audience? 
Run this report and you will find the number of pubmed.gov records for 
studies of this type, categorized by EACH AUDIENCE listed in the Persons 
branch of the Medical Subject Headings (MeSH) tree, 
https://www.ncbi.nlm.nih.gov/mesh/68009272.

The BioPython package must be installed from the Anaconda Environments tab.
(I know very little about this package; this is not an endorsement.)
More info: http://biopython.org/DIST/docs/tutorial/Tutorial.html

Note: Studies recently added to Medline will be left out, because 
this procedure only retrieves records that already have MeSH indexing 
assigned. You might be missing months or years of the latest studies.  
By setting the date range to 6 years back, you will probably be retrieving 
at least 5 years of records; in many cases, this will NOT include the 
current year. Contact me for ways to search that will somewhat solve this 
problem, with manual intervention from you.
"""

import pandas as pd
from Bio import Entrez
import time

# Always tell NCBI who you are; if you don't, they may block you.
Entrez.email =  "A.N@example.gov"

'''
# If you need the list of database names
handle = Entrez.einfo()
result = handle.read()
handle.close()
print(result)
'''

# Foundational search strategy (unpaired), total record count
totRecords = Entrez.egquery(term='"Information Seeking Behavior"[Mesh] AND "last 6 year"[dp]"')
record = Entrez.read(totRecords)
totRecords.close()
for row in record["eGQueryResult"]: # eGQueryResult returns the record count
     if row["DbName"]=="pubmed":
         print('Total records found = ' + row["Count"])


# Load several levels of the Persons branch of MeSH
audienceList = pd.read_csv('personsBranch.csv')

'''
# FYI's for occasional use
audienceList.head()
audienceList.columns
len(audienceList)

# As needed - when creating a new strategy, try small sample
testList = audienceList[2:10]
testList
'''

# Get row count; use audienceList or testList
rowCount =  audienceList.shape[0]

'''
# As needed, confirm you can loop over audienceList correctly:
for i in range(rowCount):
    print(audienceList.iloc[i]["MeSH"])
'''

# Core search strategy; everything outside term list. Escape characters as needed; 
coreStrat = '[Mesh] AND \"Information Seeking Behavior\"[Mesh] AND \"last 6 year\"[dp]'
coreStrat

'''
# If you want to test at pubmed.gov. Change first term at pubmed.gov if zero retrievals
showWholeStrat = '"' + testList.iloc[0]["MeSH"] + '"' + coreStrat
showWholeStrat
'''

# Do one pubmed search for each row; return each term and its record count
rowCount =  audienceList.shape[0]

for i in range(rowCount):
    strat = audienceList.iloc[i]['MeSH'] + coreStrat
    search_handle = Entrez.esearch(db="pubmed", term=strat, rettype="count")
    search_results = Entrez.read(search_handle)
    search_handle.close()
    print(audienceList.iloc[i]["MeSH"] + ' ' + search_results["Count"])
    time.sleep(.25) # Limit requests per second or NCBI will block you!!

finalAdvice = "Search at pubmed.gov using AudienceTermHere" + coreStrat
print(finalAdvice)
